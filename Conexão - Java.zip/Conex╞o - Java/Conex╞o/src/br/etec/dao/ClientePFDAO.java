/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.etec.dao;

import br.etec.bean.ClientePF;
import br.etec.conexao.ClassConexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Aluno
 */
public class ClientePFDAO extends ClientePF {

    private Connection Con;

  public ClientePFDAO (){
        try {
            Con = ClassConexao.getConexao();
        } catch (SQLException ex) {
            Logger.getLogger(ClientePFDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClientePFDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
  }

        public void incluir (ClientePF cliente) throws SQLException{

         String sqlincluir = "insert into cliente(Nome, Numero, Rua, Bairro," +
                 "Complemento, Cidade, UF, Email, Telefone_Celular, Telefone_Resid, CPF, RG, Sexo, CEP)" +
                   "values(?,?,?,?,?,?,?,?,?,?,?)";
         PreparedStatement smt = Con.prepareStatement(sqlincluir);
         smt.setString(1,cliente.getNome());
         smt.setInt(2,cliente.getNumero());
         smt.setString(3,cliente.getRua());
         smt.setString(4,cliente.getBairro());
         smt.setString(5,cliente.getComplemento());
         smt.setString(6,cliente.getCidade());
         smt.setString(7,cliente.getUF());
         smt.setString(8,cliente.getEmail());
         smt.setString(9,cliente.getTelefone_celular());
         smt.setString(10,cliente.getTelefone_resid());
         smt.setString(11,cliente.getCPF());
         smt.setString(12,cliente.getRG());
         smt.setString(13,cliente.getSexo());
         smt.setString(14,cliente.getCEP());
         smt.executeUpdate();
         smt.close();
         Con.close();
     }
       

public void alterar(ClientePF cliente) throws SQLException {

String sqlalt = "update cliente set Nome=?,Numero=?,Rua=?,Bairro=?,Complemento=?,Cidade=?," +
                 "UF=?,Telefone_resid=?,fonecelcli=?,email=?,cpfcli=?,rgcli=? where codcli=?";
         PreparedStatement smt = this.Con.prepareStatement(sqlalt);
          smt.setString(1,cliente.getNome());
          smt.setInt(2,cliente.getNumero());
          smt.setString(3,cliente.getRua());
          smt.setString(4,cliente.getBairro());
          smt.setString(5,cliente.getComplemento());
          smt.setString(6,cliente.getCidade());
          smt.setString(7,cliente.getUF());
          smt.setString(8,cliente.getEmail());
          smt.setString(9,cliente.getTelefone_resid());
          smt.setString(10,cliente.getTelefone_celular());
          smt.setString(11,cliente.getCPF());
          smt.setString(12,cliente.getRG());
          smt.setString(13,cliente.getSexo());
          smt.setString(14,cliente.getCEP());
          smt.setInt(15,cliente.getCodigo());
          smt.executeUpdate();
          smt.close();
          Con.close();
     }
public void getList(String nome,JTable jTable1) throws SQLException{
        String sql = "SELECT * FROM ClientePFDAO WHERE nomecli like '%" +  nome + "%'";

         PreparedStatement ppt = Con.prepareStatement(sql);

         ResultSet res = ppt.executeQuery();


        DefaultTableModel model =(DefaultTableModel) jTable1.getModel();
                 model.setNumRows(0);

                while (res.next()){
                    model.addRow(new Object[]{res.getInt("Codigo"),
                    res.getString("Nome"),res.getString("CPF"),res.getString("RG"),
                    res.getString("Rua"),res.getString("Complemento"),res.getString("Numero"),
                    res.getString("Bairro"),res.getString("Cidade"),res.getString("UF"),
                    res.getString("CEP"),res.getString("Telefone_celular"),res.getString("Telefone_resid"),
                    res.getString("Email"),res.getString("emptrabalhocli"),res.getString("funccli"),
                    res.getString("fonecomercialcli"),res.getString("datadmincli"),res.getDouble("salariocli"),
                    res.getString("situacaocli"),res.getString("absdasituacao")});

                  }

                 ppt.close();
                 res.close();
                Con.close();
              System.out.println("Desconectado do banco");

     }
}
