/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.etec.dao;

import br.etec.bean.ClientePJ;

/**
 *
 * @author Aluno
 */
public class ClientePJDAO extends ClientePJ {

}
