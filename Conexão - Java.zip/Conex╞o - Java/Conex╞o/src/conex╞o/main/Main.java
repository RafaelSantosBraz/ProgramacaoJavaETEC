/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package conexão.main;

import br.etec.bean.ClientePF;
import br.etec.conexao.ClassConexao;
import br.etec.dao.ClientePFDAO;
import br.etec.grafico.FRMClientePessoaFisica;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Aluno
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException  {
        try {
//        try {
//            Connection com = ClassConexao.getConexao();
//            com.close();
//        } catch (SQLException ex) {
//            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (ClassNotFoundException ex) {
//            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
//        }
            ClientePF cliente = new ClientePF();
            cliente.setNome("Bianca Leandro Vicente");
            cliente.setNumero(123);
            cliente.setRua("Honorio Simao");
            cliente.setBairro("Popular Nova");
            cliente.setComplemento("Edicula");
            cliente.setCidade("Duartina");
            cliente.setUF("SP");
            cliente.setEmail("bianca.vicente98@hotmail.com");
            cliente.setTelefone_celular("014996589854");
            cliente.setTelefone_resid("01432823282");
            cliente.setCPF("22222222");
            cliente.setRG("111111111");
            cliente.setSexo("F");
            cliente.setCEP("17470000");
            ClientePFDAO dao = new ClientePFDAO();
            dao.incluir(cliente);
            System.out.println("adicionado no banco");
        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }

ClientePF cliente = new ClientePF();
        cliente.setCodigo(2);
        cliente.setNome("Bianca Leandro");
        cliente.setNumero(123);
        cliente.setRua("Honorio Simao");
        cliente.setBairro("Popular Nova");
        cliente.setComplemento("Edicula");
        cliente.setCidade("Duartina");
        cliente.setUF("SP");
        cliente.setEmail("bianca.vicente98@hotmail.com");
        cliente.setTelefone_celular("99658-9854");
        cliente.setTelefone_resid("3282-3282");
        cliente.setCPF("22222222");
        cliente.setRG("111111111");
        cliente.setSexo("F");
        cliente.setCEP("17470000");
        ClientePFDAO dao = new ClientePFDAO();
        dao.alterar(cliente);
        System.out.println("dados alterados no banco");
        FRMClientePessoaFisica.main(args);
}
}
