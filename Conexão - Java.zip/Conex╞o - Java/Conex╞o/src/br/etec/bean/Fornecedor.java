/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.etec.bean;

/**
 *
 * @author Aluno
 */
public class Fornecedor extends Pessoas {

    private String CNPJ;
    private String telefone_comerc;

    public String getTelefone_comerc() {
        return telefone_comerc;
    }

    public void setTelefone_comerc(String telefone_comerc) {
        this.telefone_comerc = telefone_comerc;
    }
    

    public String getCNPJ() {
        return CNPJ;
    }

    public void setCNPJ(String CNPJ) {
        this.CNPJ = CNPJ;
    }
    
}
