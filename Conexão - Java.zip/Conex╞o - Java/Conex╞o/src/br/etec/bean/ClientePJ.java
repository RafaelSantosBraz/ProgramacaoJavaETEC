/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.etec.bean;

/**
 *
 * @author Aluno
 */
public class ClientePJ extends Pessoas {

    private String CNPJ;
    private String telefone_resid;

    public String getTelefone_resid() {
        return telefone_resid;
    }

    public void setTelefone_resid(String telefone_resid) {
        this.telefone_resid = telefone_resid;
    }
    

    public String getCNPJ() {
        return CNPJ;
    }

    public void setCNPJ(String CNPJ) {
        this.CNPJ = CNPJ;
    }

}
