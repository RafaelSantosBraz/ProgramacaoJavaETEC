/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.etec.main;

import br.etec.conexao.ClassConexao;
import br.etec.grafico.FRMClientePessoaFisica;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Aluno
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)  {
        FRMClientePessoaFisica.main(args);
}
}
