/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.etec.bean;

/**
 *
 * @author Aluno
 */
public class Usuario {

    private int cod_usuario;
    private String nome;
    private String login;
    private String senha;

    public int getCod_usuario() {
        return cod_usuario;
    }

    public void setCod_usuario(int cod_usuario) {
        this.cod_usuario = cod_usuario;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

}
