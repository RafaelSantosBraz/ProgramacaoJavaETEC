/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.etec.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Aluno
 */
public class ClassConexao {
     public static Connection getConexao() throws SQLException, ClassNotFoundException {
         System.out.println("Conectado ao banco");
        return DriverManager.getConnection("jdbc:mysql://127.0.0.1/bdloja", "root", "");

    }


     }

