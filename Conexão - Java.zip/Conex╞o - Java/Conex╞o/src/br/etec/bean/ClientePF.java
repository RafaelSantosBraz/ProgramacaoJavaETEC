/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.etec.bean;

/**
 *
 * @author Aluno
 */
public class ClientePF extends Pessoas {

    private String RG;
    private String CPF;
    private String telefone_resid;

    public String getTelefone_resid() {
        return telefone_resid;
 
    }

    public void setTelefone_resid(String telefone_resid) {
        this.telefone_resid = telefone_resid;
    }
    

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getRG() {
        return RG;
    }

    public void setRG(String RG) {
        this.RG = RG;
    }

}
