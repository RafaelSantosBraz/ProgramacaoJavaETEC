/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.etec.bean;

/**
 *
 * @author Aluno
 */
public class Vendas {

    private int cod_vendas;
    private String nome_cliente;
    private String docum_cliente;
    private String produto;
    private int quantidade;
    private double valor_unit;
    private double total_compra;

    public int getCod_vendas() {
        return cod_vendas;
    }

    public void setCod_vendas(int cod_vendas) {
        this.cod_vendas = cod_vendas;
    }

    public String getDocum_cliente() {
        return docum_cliente;
    }

    public void setDocum_cliente(String docum_cliente) {
        this.docum_cliente = docum_cliente;
    }

    public String getNome_cliente() {
        return nome_cliente;
    }

    public void setNome_cliente(String nome_cliente) {
        this.nome_cliente = nome_cliente;
    }

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getTotal_compra() {
        return total_compra;
    }

    public void setTotal_compra(double total_compra) {
        this.total_compra = total_compra;
    }

    public double getValor_unit() {
        return valor_unit;
    }

    public void setValor_unit(double valor_unit) {
        this.valor_unit = valor_unit;
    }


}
